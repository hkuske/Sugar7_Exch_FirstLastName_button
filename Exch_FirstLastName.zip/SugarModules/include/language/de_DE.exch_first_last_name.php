<?php 
$mod_strings['LBL_EXC_FIRST_LAST_NAME'] = 'Vor-/Nachname tauschen';
?>
