<?php 
$mod_strings['LBL_EXC_FIRST_LAST_NAME'] = 'Exchange First/Last Name';
?>
